import logo from './logo.svg';
import './App.css';
import Projects from './pages/Projects';
import MyForm from './pages/MyForm';
import MyTable from './pages/MyTable';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React from 'react';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Projects />} />
        <Route path="/form" element={<MyForm />} />
        <Route path="/projects" element={<MyTable />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
