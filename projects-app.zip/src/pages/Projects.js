import React from 'react';
import ReactDOM from 'react-dom/client';
function Projects() {
  return <h2>Hi, I am a Project!</h2>;
}

export default Projects;