import React from 'react';
import ReactDOM from 'react-dom/client';

class Projects extends React.Component {
   
    // Constructor 
    constructor(props) {
        super(props);
   
        this.state = {
            items: [],
            DataisLoaded: false
        };
    }
   
    // ComponentDidMount is used to
    // execute the code 
    componentDidMount() {
        fetch(
"/api/projects/all")
            .then((res) => res.json())
            .then((json) => {
                this.setState({
                    items: json,
                    DataisLoaded: true
                });
                //alert("fetched");
            })
    }
    render() {
        const { DataisLoaded, items } = this.state;
        if (!DataisLoaded) return <div>
            <h1> Pleses wait some time.... </h1> </div> ;
   
        return (

        <div className = "App">
        
	        <table>
	        <tr>
	          <th>Paascode</th>
	          <th>Approved?</th>
	          <th>Title</th>
	        </tr>
            
             {
                items.map((item) => ( 
                <tr key={item.projectID}>
	              <td>{item.paascode}</td>
	              <td>{item.approvedStatus}</td>
	              <td>{item.projectTitle}</td>
	              <td><form><input type="submit" value="View" /></form></td>
	              <td><form><input type="submit" value="Edit" /></form></td>
	              <td><form><input type="submit" value="Delete" /></form></td>
	            </tr>
               
                ))
            }
            
            </table>
            <div class="next">
            	<form><input type="submit" value="Next"/></form>
            </div>
        </div>
    );
}
}

export default Projects;